#define SECRET_APP_EUI ""
#define SECRET_APP_KEY ""
